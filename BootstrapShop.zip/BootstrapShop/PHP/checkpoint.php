<?php
include "./configUser.php";
$base= connect();

$email=$_POST['email'];

$password=$_POST['password'];
$requette="Select role from users where email='$email' and password='$password'";

$data=$base->query($requette);
$role=$data->fetchObject();

if ($role==null)
{
    ?>  
    <script>alert("This is not a valid account !\nPlease try again !");</script>
    <?php
    
}
else if ($role->role=="user")
{header ('location:./interfaceuser.php');
}
else if ($role->role=="admin")
{header ('location:./admin/home.php');
}


?>