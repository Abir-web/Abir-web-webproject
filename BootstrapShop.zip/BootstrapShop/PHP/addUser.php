<?php
include "./configUser.php";
$base= connect();

$fname=$_POST['fname'];

$lname=$_POST['lname'];

$phone=$_POST['phone'];

$mail=$_POST['mail'];

$password=$_POST['password'];

$role="user";

$requette="INSERT INTO users VALUES (null,'$fname','$lname',$phone,'$mail','$password','$role')";

$lignes=$base->exec($requette);

if ($lignes==1)
header('location:./home.php');

?>