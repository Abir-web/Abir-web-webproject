<?php
include "./config.php";
$base= connect();

$id=$_GET['id'];

$name=$_POST['name'];
$descript=$_POST['description'];
$price=$_POST['price'];
$categorie=$_POST['cat'];

$requete="SELECT id from categories where '$categorie'=name";
$data=$base->query($requete);
$idd=$data->fetchObject();

$requette="UPDATE products set idCat=$idd->id, name='$name', description='$descript', price=$price 
where id=$id";
$lignes=$base->exec($requette);


header('location:./home.php');


?>