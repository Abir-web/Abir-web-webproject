<?php
include "./config.php";
$base= connect();

$name=$_POST['name'];

$descript=$_POST['description'];

$price=$_POST['price'];

$category=$_POST['cat'];

$requete="SELECT id from categories where '$category'=name";
$data=$base->query($requete);

$idd=$data->fetchObject();

$requette="INSERT INTO products VALUES (null,'$name','$descript',$price,$idd->id)";

$lignes=$base->exec($requette);

if ($lignes==1)
header('location:./home.php');
else
header('location:./viewAddProduct.php');



?>