<?php

function connect()
{
    $server="localhost";
    $database="shop";
    $username="root";
    $password="";

try{
$connexion= new PDO("mysql:host=$server;dbname=$database",$username,$password);
return $connexion;
}catch(PDOException $e){
die('Erreur: '.$e->getMessage());
}

}

?>