<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Formulaire UpdateCategory</title>  
    <link rel="stylesheet" href="./../../CSS/bootstrap.css">
</head>
<body>
   <?php
   include "config.php";
   $base=connect();
    $id=$_GET['id'];
   $requette="SELECT * from products where id=$id";

   $data=$base->query($requette);
   $product=$data->fetchObject();

   $requete="SELECT * from categories";

   $dataa=$base->query($requete);
   ?> 

   <div class="container">
       <form method="POST" action="./updateProduct.php?id= <?php echo $product ->id; ?>">
            <div class="form-group">
                <p>Name : </p>
                <input type="text" name="name" value="<?php echo $product->name; ?>" class="form-control">
            </div>

             <div class="form-group">
                <p>Description : </p>
                <input type="text" name="description" value="<?php echo $product->description; ?>" class="form-control">
            </div>

            <div class="form-group">
                <p>Price : </p>
                <input type="text" name="price" value="<?php echo $product->price; ?>" class="form-control">
            </div>

            <div class="form-group">                    
                <p>Category :</p>
                <select name="cat" >
                    <?php while ($category=$dataa->fetchObject()){ ?>
                        <option class="form-control"><?php echo $category->name; ?>
                        </option>
                    <?php  } ?>
                </select>
            </div>
                    
            <div class="form-group">
                <input type="submit" value="Update" class="btn btn-info">
            </div>
        </form>
   </div>
</body>
</html>