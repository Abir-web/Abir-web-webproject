<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>INSCRIPTION</title>
    
    <link rel="stylesheet" href="./../CSS/bootstrap.css">
</head>
<body>
<div class="container">
       <form method="POST" action="./addUser.php">
            <div class="form-group">
                <p>First Name : </p>
                <input type="text" name="fname"class="form-control" placeholder="Abir" required>
            </div>

             <div class="form-group">
                <p>Last Name : </p>
                <input type="text" name="lname" class="form-control" placeholder="TRABELSI" required>
            </div>

            <div class="form-group">
                <p>Phone : </p>
                <input type="number" name="phone" class="form-control" required>
            </div>

            <div class="form-group">
                <p>E-mail : </p>
                <input type="email" name="mail" class="form-control" placeholder="someone@example.com" required>
            </div>

            <div class="form-group">
                <p>Password : </p>
                <input type="password" name="password" class="form-control" required>
            </div>

            <div class="form-group">
                <input type="submit" value="SUBMIT" class="btn btn-danger">
            </div>
        </form>
   </div>  
</body>
</html>