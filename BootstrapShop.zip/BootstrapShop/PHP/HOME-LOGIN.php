<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HOME-LOGIN</title>
    
    <link rel="stylesheet" href="./../CSS/bootstrap.css">   
    <link rel="stylesheet" href="./../CSS/style.css">
</head>
<body>
<nav class="navbar navbar-light bg-light justify-content-between">
    
      <a class="navbar-brand" href="#"><h1>Welcome!</h1></a>
     
                
      <form method="POST" action="./checkpoint.php" class="form-inline">
    <div class="form-group">
      <input type="email" name="email" class="form-control mx-1" placeholder="E-mail" required >
      <input type="password" name="password" class="form-control mx-3" placeholder="Password" required>
    </div>
    <a href="./Connexion.html" target="_blank"> <input class="btn btn-danger" type="submit" value="Connexion"></a>       
      
  </form>
     
           
  </nav>
  
</body>
</html>