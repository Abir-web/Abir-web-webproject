create table users(
    id int AUTO_INCREMENT,
    first_name varchar (30) NOT NULL,
    last_name varchar (30) NOT NULL,
    phone varchar (20) NOT NULL,
    email varchar (20) NOT NULL,
    password varchar (20) NOT NULL,
    role varchar (10) NOT NULL,
    CONSTRAINT pk_users PRIMARY KEY (id)
);